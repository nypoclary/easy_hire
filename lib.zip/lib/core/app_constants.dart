class AppConstants {
  static const String appName = 'Easy Hire';
}